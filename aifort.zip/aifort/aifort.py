# Import standard library modules for cryptographic hashing
import hashlib
# Import module for interacting with the operating system (file operations, terminal clearing)
import os
# Import module for handling date and time operations
import datetime
# Import module for guessing file MIME types
import mimetypes
# Import module for regular expression pattern matching
import re
# Import Path class for cross-platform file path handling
from pathlib import Path
# Import scapy functions for reading and analyzing PCAP files (network traffic)
from scapy.all import rdpcap, IP, TCP, UDP
# Import PIL (Python Imaging Library) for image processing and EXIF metadata extraction
from PIL import Image
# Import TAGS for mapping EXIF tag IDs to human-readable names
from PIL.ExifTags import TAGS

# Define the AIFORT class for digital forensic analysis
class AIFORT:
    # Initialize the class with instance variables
    def __init__(self):
        # Store the target directory for analysis (used by some methods)
        self.target_dir = ""
        # Dictionary to store analysis results for reporting
        self.results = {}

    # Clear the terminal screen for a clean user interface
    def clear_screen(self):
        # Use 'cls' on Windows ('nt') and 'clear' on Unix-based systems
        os.system('cls' if os.name == 'nt' else 'clear')

    def latex_escape(self, text):
        """Escape special LaTeX characters."""
        # Convert non-string input to string for processing
        if not isinstance(text, str):
            text = str(text)
        # Define dictionary mapping special characters to their LaTeX escape sequences
        chars = {
            '&': r'\&',
            '%': r'\%',
            '$': r'\$',
            '#': r'\#',
            '_': r'\_',
            '{': r'\{',
            '}': r'\}',
            '~': r'\textasciitilde{}',
            '^': r'\textasciicircum{}',
            '\\': r'\textbackslash{}'
        }
        # Replace each special character with its LaTeX escape sequence
        for char, escape in chars.items():
            text = text.replace(char, escape)
        # Return the escaped text
        return text

    def get_file_hashes(self, file_path):
        """Calculate MD5, SHA1, and SHA256 hashes of a file."""
        try:
            # Initialize hash objects for MD5, SHA1, and SHA256
            md5_hash = hashlib.md5()
            sha1_hash = hashlib.sha1()
            sha256_hash = hashlib.sha256()

            # Open the file in binary read mode
            with open(file_path, "rb") as f:
                # Read file in 4KB chunks for memory efficiency
                for chunk in iter(lambda: f.read(4096), b""):
                    # Update each hash object with the chunk
                    md5_hash.update(chunk)
                    sha1_hash.update(chunk)
                    sha256_hash.update(chunk)

            # Store hash results in a dictionary
            result = {
                "MD5": md5_hash.hexdigest(),
                "SHA1": sha1_hash.hexdigest(),
                "SHA256": sha256_hash.hexdigest()
            }
            # Save results to self.results for reporting
            self.results["File Hashes"] = result
            # Return the hash dictionary
            return result
        except Exception as e:
            # Return error message if hash calculation fails
            return f"Error calculating hashes: {str(e)}"

    def extract_metadata(self, file_path):
        """Extract metadata of a file, including EXIF for images."""
        try:
            # Get file statistics (size, timestamps)
            file_stat = os.stat(file_path)
            # Create dictionary with basic file metadata
            metadata = {
                "File Name": os.path.basename(file_path),
                "Size": f"{file_stat.st_size} bytes",
                "Created": datetime.datetime.fromtimestamp(file_stat.st_ctime).strftime('%Y-%m-%d %H:%M:%S'),
                "Modified": datetime.datetime.fromtimestamp(file_stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
                "Accessed": datetime.datetime.fromtimestamp(file_stat.st_atime).strftime('%Y-%m-%d %H:%M:%S'),
                "Path": file_path
            }

            # Check if the file is an image (JPEG, PNG, TIFF)
            if file_path.lower().endswith(('.jpg', '.jpeg', '.png', '.tiff')):
                try:
                    # Open image file using PIL
                    with Image.open(file_path) as img:
                        # Extract EXIF metadata
                        exif_data = img._getexif()
                        # If EXIF data exists, process it
                        if exif_data:
                            exif = {}
                            # Map EXIF tag IDs to names and store values
                            for tag, value in exif_data.items():
                                tag_name = TAGS.get(tag, tag)
                                exif[tag_name] = value
                            metadata["EXIF Data"] = exif
                except Exception as e:
                    # Store error message if EXIF extraction fails
                    metadata["EXIF Data"] = f"Error extracting EXIF: {str(e)}"

            # Save metadata to self.results for reporting
            self.results["Metadata"] = metadata
            # Return the metadata dictionary
            return metadata
        except Exception as e:
            # Return error message if metadata extraction fails
            return f"Error extracting metadata: {str(e)}"

    def file_signature_analysis(self, file_path):
        """Analyze file signature to verify file type."""
        try:
            # Guess the MIME type of the file
            mime_type, _ = mimetypes.guess_type(file_path)
            # Open file in binary mode to read header
            with open(file_path, 'rb') as f:
                # Read first 8 bytes and convert to hex
                header = f.read(8).hex()
            # Store analysis results in a dictionary
            result = {
                "File": os.path.basename(file_path),
                "MIME Type": mime_type if mime_type else "Unknown",
                "Header (First 8 bytes)": header
            }
            # Save results to self.results for reporting
            self.results["File Signature"] = result
            # Return the result dictionary
            return result
        except Exception as e:
            # Return error message if signature analysis fails
            return f"Error in file signature analysis: {str(e)}"

    def keyword_search(self, directory, keyword):
        """Search for a keyword in files within a directory."""
        # Initialize list to store matching file paths
        results = []
        try:
            # Walk through the directory recursively
            for root, _, files in os.walk(directory):
                for file in files:
                    # Construct full file path
                    file_path = os.path.join(root, file)
                    try:
                        # Open file in text mode, ignoring encoding errors
                        with open(file_path, 'r', errors='ignore') as f:
                            # Read entire file content
                            content = f.read()
                            # Check if keyword exists (case-insensitive)
                            if keyword.lower() in content.lower():
                                results.append(f"Match found in {file_path}")
                    except:
                        # Skip files that cannot be read
                        continue
            # Set result to list of matches or a default message
            result = results if results else "No matches found."
            # Save results to self.results for reporting
            self.results["Keyword Search"] = result
            # Return the result
            return result
        except Exception as e:
            # Return error message if keyword search fails
            return f"Error in keyword search: {str(e)}"

    def timeline_analysis(self, directory):
        """Create a timeline of file activities."""
        # Initialize list to store timeline entries
        timeline = []
        try:
            # Walk through the directory recursively
            for root, _, files in os.walk(directory):
                for file in files:
                    # Construct full file path
                    file_path = os.path.join(root, file)
                    # Get file statistics
                    file_stat = os.stat(file_path)
                    # Create dictionary with file timestamps
                    timeline.append({
                        "File": file_path,
                        "Created": datetime.datetime.fromtimestamp(file_stat.st_ctime).strftime('%Y-%m-%d %H:%M:%S'),
                        "Modified": datetime.datetime.fromtimestamp(file_stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
                        "Accessed": datetime.datetime.fromtimestamp(file_stat.st_atime).strftime('%Y-%m-%d %H:%M:%S')
                    })
            # Sort timeline by modification time (descending)
            result = sorted(timeline, key=lambda x: x["Modified"], reverse=True)
            # Save results to self.results for reporting
            self.results["Timeline Analysis"] = result
            # Return the sorted timeline
            return result
        except Exception as e:
            # Return error message if timeline analysis fails
            return f"Error in timeline analysis: {str(e)}"

    def detect_hidden_files(self, directory):
        """Detect hidden files in a directory."""
        # Initialize list to store hidden file paths
        hidden_files = []
        try:
            # Walk through the directory recursively
            for root, _, files in os.walk(directory):
                for file in files:
                    # Check if file starts with a dot (hidden file)
                    if file.startswith('.'):
                        hidden_files.append(os.path.join(root, file))
            # Set result to list of hidden files or a default message
            result = hidden_files if hidden_files else "No hidden files found."
            # Save results to self.results for reporting
            self.results["Hidden Files"] = result
            # Return the result
            return result
        except Exception as e:
            # Return error message if hidden file detection fails
            return f"Error detecting hidden files: {str(e)}"

    def parse_log_file(self, log_file):
        """Parse a log file for common patterns (e.g., IPs, timestamps)."""
        try:
            # Define regex patterns for IP addresses and timestamps
            ip_pattern = r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b'
            timestamp_pattern = r'\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}'
            # Initialize dictionary to store parsed patterns
            results = {"IPs": [], "Timestamps": []}
            
            # Open log file in text mode, ignoring encoding errors
            with open(log_file, 'r', errors='ignore') as f:
                # Process each line
                for line in f:
                    # Find all IP addresses in the line
                    ips = re.findall(ip_pattern, line)
                    # Find all timestamps in the line
                    timestamps = re.findall(timestamp_pattern, line)
                    # Add found IPs to results
                    if ips:
                        results["IPs"].extend(ips)
                    # Add found timestamps to results
                    if timestamps:
                        results["Timestamps"].extend(timestamps)
            
            # Set result to parsed patterns or a default message
            result = results if results["IPs"] or results["Timestamps"] else "No patterns found."
            # Save results to self.results for reporting
            self.results["Log File Parser"] = result
            # Return the result
            return result
        except Exception as e:
            # Return error message if log parsing fails
            return f"Error parsing log file: {str(e)}"

    def generate_pdf_report(self, output_path):
        """Generate a PDF report of all analysis results using LaTeX."""
        try:
            # Define LaTeX document preamble and content
            latex_content = r"""
\documentclass[a4paper,12pt]{article}
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{geometry}
\geometry{margin=1in}
\usepackage{enumitem}
\usepackage{hyperref}
\usepackage{longtable}
\usepackage{times}

\begin{document}

\title{AIFORT Forensic Analysis Report}
\author{AIFORT Tool}
\date{\today}
\maketitle

\section{Introduction}
This report contains the results of the forensic analysis performed by the AIFORT (Artificial Intelligence Forensic Tool). The analysis includes file hashing, metadata extraction, file signature analysis, keyword search, timeline analysis, hidden file detection, log file parsing, network traffic analysis, advanced metadata extraction, DeepSeek chat assistance, and Open AI chat assistance.

"""

            # Iterate through stored analysis results
            for analysis, result in self.results.items():
                # Add section for each analysis type
                latex_content += f"\\section{{{self.latex_escape(analysis)}}}\n"
                # Handle dictionary results (e.g., file hashes, metadata)
                if isinstance(result, dict):
                    latex_content += "\\begin{itemize}\n"
                    for key, value in result.items():
                        # Handle nested dictionaries (e.g., EXIF data)
                        if isinstance(value, dict):
                            latex_content += f"\\item \\textbf{{{self.latex_escape(key)}}}: \n"
                            latex_content += "\\begin{itemize}\n"
                            for subkey, subvalue in value.items():
                                latex_content += f"\\item {self.latex_escape(subkey)}: {self.latex_escape(subvalue)}\n"
                            latex_content += "\\end{itemize}\n"
                        else:
                            latex_content += f"\\item \\textbf{{{self.latex_escape(key)}}}: {self.latex_escape(value)}\n"
                    latex_content += "\\end{itemize}\n"
                # Handle list results (e.g., keyword search, timeline)
                elif isinstance(result, list):
                    latex_content += "\\begin{itemize}\n"
                    for item in result:
                        # Handle dictionary items (e.g., timeline entries)
                        if isinstance(item, dict):
                            latex_content += "\\item \n"
                            latex_content += "\\begin{itemize}\n"
                            for key, value in item.items():
                                latex_content += f"\\item {self.latex_escape(key)}: {self.latex_escape(value)}\n"
                            latex_content += "\\end{itemize}\n"
                        else:
                            latex_content += f"\\item {self.latex_escape(item)}\n"
                    latex_content += "\\end{itemize}\n"
                # Handle string results (e.g., error messages)
                else:
                    latex_content += f"{self.latex_escape(result)}\n"

            # Close LaTeX document
            latex_content += r"\end{document}"

            # Create .tex file path from output_path
            tex_path = os.path.splitext(output_path)[0] + ".tex"
            # Write LaTeX content to file
            with open(tex_path, 'w') as f:
                f.write(latex_content)

            # Compile LaTeX to PDF using latexmk
            os.system(f"latexmk -pdf -interaction=nonstopmode {tex_path}")

            # Return success message with output path
            return f"PDF report generated at {output_path}"
        except Exception as e:
            # Return error message if PDF generation fails
            return f"Error generating PDF report: {str(e)}"

    def analyze_network_traffic(self, pcap_file):
        """Analyze PCAP file for network traffic details."""
        try:
            # Read packets from PCAP file
            packets = rdpcap(pcap_file)
            # Initialize dictionary to store analysis results
            result = {
                "Total Packets": len(packets),
                "Protocols": set(),
                "Source IPs": set(),
                "Destination IPs": set(),
                "Ports": set()
            }

            # Iterate through each packet
            for pkt in packets:
                # Extract IP layer information
                if IP in pkt:
                    result["Source IPs"].add(pkt[IP].src)
                    result["Destination IPs"].add(pkt[IP].dst)
                    result["Protocols"].add(pkt[IP].proto)
                # Extract TCP layer information
                if TCP in pkt:
                    result["Ports"].add(pkt[TCP].sport)
                    result["Ports"].add(pkt[TCP].dport)
                # Extract UDP layer information
                elif UDP in pkt:
                    result["Ports"].add(pkt[UDP].sport)
                    result["Ports"].add(pkt[UDP].dport)

            # Convert sets to lists for JSON compatibility
            result["Protocols"] = list(result["Protocols"])
            result["Source IPs"] = list(result["Source IPs"])
            result["Destination IPs"] = list(result["Destination IPs"])
            result["Ports"] = list(result["Ports"])
            # Save results to self.results for reporting
            self.results["Network Traffic Analysis"] = result
            # Return the result dictionary
            return result
        except Exception as e:
            # Return error message if PCAP analysis fails
            return f"Error analyzing PCAP file: {str(e)}"

    def deepseek_chat_assistance(self, user_query):
        """Simulate DeepSeek chat assistance for forensic queries."""
        try:
            # Convert query to lowercase for case-insensitive matching
            query = user_query.lower()
            # Initialize response string
            response = ""

            # Check query for specific keywords and provide tailored responses
            if "hash" in query or "md5" in query or "sha" in query:
                response = ("File hashes like MD5, SHA1, or SHA256 are used to verify file integrity. "
                           "If you have hash results, compare them against known values to detect tampering. "
                           "Would you like to know how to verify hashes against a database?")
            elif "metadata" in query or "exif" in query:
                response = ("Metadata, including EXIF for images, can reveal creation dates, locations, or device info. "
                           "Check the 'File Metadata Extraction' results for details. "
                           "Do you want guidance on analyzing EXIF data for geolocation?")
            elif "pcap" in query or "network" in query:
                response = ("PCAP analysis shows network traffic details like IPs and ports. "
                           "Look for unusual IPs or ports in the 'Analyze Network Traffic' results. "
                           "Would you like to filter specific protocols like HTTP or DNS?")
            elif "keyword" in query or "search" in query:
                response = ("Keyword search helps locate evidence in files. "
                           "Use specific terms related to your case for better results. "
                           "Do you need help crafting effective search terms?")
            elif "timeline" in query:
                response = ("Timeline analysis shows file activity dates. "
                           "Sort by 'Modified' to find recently altered files, which may indicate tampering. "
                           "Want tips on correlating timelines with other evidence?")
            elif "hidden" in query:
                response = ("Hidden files (starting with '.') may contain critical evidence. "
                           "Check the 'Hidden File Detection' results for suspicious files. "
                           "Need advice on analyzing hidden files safely?")
            elif "log" in query or "parser" in query:
                response = ("Log file parsing extracts IPs and timestamps. "
                           "Look for patterns like repeated IPs in the 'Log File Parser' results. "
                           "Would you like to learn about log correlation with network data?")
            elif "report" in query or "pdf" in query:
                response = ("The PDF report compiles all analysis results. "
                           "Run all relevant analyses before generating it to ensure completeness. "
                           "Do you need help interpreting the report structure?")
            else:
                response = ("I can assist with forensic analysis tasks like hashing, metadata, or network traffic. "
                           "Please provide more details or ask a specific question about your investigation.")

            # Create chat log with query and response
            chat_log = {"Query": user_query, "Response": response}
            # Initialize chat assistance results if not present
            if "DeepSeek Chat Assistance" not in self.results:
                self.results["DeepSeek Chat Assistance"] = []
            # Append chat log to results
            self.results["DeepSeek Chat Assistance"].append(chat_log)
            # Return the chat log
            return chat_log
        except Exception as e:
            # Return error message if chat assistance fails
            return f"Error in DeepSeek chat assistance: {str(e)}"

    def openai_chat_assistance(self, user_query):
        """Simulate Open AI chat assistance for forensic queries."""
        try:
            # Convert query to lowercase for case-insensitive matching
            query = user_query.lower()
            # Initialize response string
            response = ""

            # Check query for specific keywords and provide tailored responses
            if "hash" in query or "md5" in query or "sha" in query:
                response = ("Hashes (MD5, SHA1, SHA256) ensure file authenticity. "
                           "Use the 'File Hashing' results to check for file alterations. "
                           "Need help comparing these hashes with a trusted source?")
            elif "metadata" in query or "exif" in query:
                response = ("Metadata provides critical file details, like EXIF for images showing camera info. "
                           "Review the 'File Metadata Extraction' output for insights. "
                           "Want tips on using EXIF for case evidence?")
            elif "pcap" in query or "network" in query:
                response = ("PCAP files reveal network activity, including IPs and ports. "
                           "Check 'Analyze Network Traffic' for anomalies. "
                           "Interested in identifying malicious traffic patterns?")
            elif "keyword" in query or "search" in query:
                response = ("Keyword searches pinpoint relevant data in files. "
                           "Try targeted keywords in 'Keyword Search' for efficiency. "
                           "Need suggestions for forensic keyword strategies?")
            elif "timeline" in query:
                response = ("Timeline analysis tracks file changes over time. "
                           "Use 'Timeline Analysis' to spot suspicious modifications. "
                           "Would you like advice on building a case timeline?")
            elif "hidden" in query:
                response = ("Hidden files can hide evidence. "
                           "Inspect 'Hidden File Detection' results for unusual files. "
                           "Want guidance on safely extracting hidden file contents?")
            elif "log" in query or "parser" in query:
                response = ("Log parsing identifies key patterns like IPs or timestamps. "
                           "See 'Log File Parser' results for clues. "
                           "Need help cross-referencing logs with other data?")
            elif "report" in query or "pdf" in query:
                response = ("The PDF report summarizes all findings. "
                           "Ensure all analyses are run before using 'Generate PDF Report'. "
                           "Want assistance formatting your forensic report?")
            else:
                response = ("I'm here to help with your forensic investigation. "
                           "Ask about specific tools like hashing or PCAP analysis, or describe your case for tailored advice.")

            # Create chat log with query and response
            chat_log = {"Query": user_query, "Response": response}
            # Initialize chat assistance results if not present
            if "Open AI Chat Assistance" not in self.results:
                self.results["Open AI Chat Assistance"] = []
            # Append chat log to results
            self.results["Open AI Chat Assistance"].append(chat_log)
            # Return the chat log
            return chat_log
        except Exception as e:
            # Return error message if chat assistance fails
            return f"Error in Open AI chat assistance: {str(e)}"

    def run(self):
        # Main loop for the interactive menu
        while True:
            # Clear the terminal for a clean interface
            self.clear_screen()
            # Display the main menu
            print("=== AIFORT: AI-Enhanced Intelligence Forensic Tool ===")
            print("1. File Hashing")
            print("2. File Metadata Extraction (Advanced)")
            print("3. File Signature Analysis")
            print("4. Keyword Search")
            print("5. Timeline Analysis")
            print("6. Hidden File Detection")
            print("7. Log File Parser")
            print("8. Generate PDF Report")
            print("9. Analyze Network Traffic (PCAP)")
            print("10. DeepSeek Chat Assistance")
            print("11. Open AI Chat Assistance")
            print("12. Exit")
            
            # Get user input for menu choice
            choice = input("\nEnter your choice (1-12): ")

            # Exit the program if user selects 12
            if choice == '12':
                print("Exiting AIFORT. Goodbye!")
                break

            # Prompt for file path for options requiring a file
            if choice in ['1', '2', '3', '7', '9']:
                file_path = input("Enter file path: ")
                # Validate file existence
                if not os.path.exists(file_path):
                    print("File does not exist!")
                    input("Press Enter to continue...")
                    continue

            # Prompt for directory path for options requiring a directory
            if choice in ['4', '5', '6']:
                self.target_dir = input("Enter directory path: ")
                # Validate directory existence
                if not os.path.isdir(self.target_dir):
                    print("Directory does not exist!")
                    input("Press Enter to continue...")
                    continue

            # Prompt for output PDF path for report generation
            if choice == '8':
                output_path = input("Enter output PDF path (e.g., report.pdf): ")
                # Ensure output path ends with .pdf
                if not output_path.endswith('.pdf'):
                    output_path += '.pdf'

            # Prompt for user query for chat assistance options
            if choice in ['10', '11']:
                user_query = input("Enter your forensic question or query: ")

            # Clear screen before displaying results
            self.clear_screen()
            # Handle File Hashing
            if choice == '1':
                print("=== File Hashing ===")
                result = self.get_file_hashes(file_path)
                # Display hash results
                for key, value in result.items():
                    print(f"{key}: {value}")
            
            # Handle File Metadata Extraction
            elif choice == '2':
                print("=== File Metadata Extraction (Advanced) ===")
                result = self.extract_metadata(file_path)
                # Display metadata, handling nested dictionaries
                for key, value in result.items():
                    if isinstance(value, dict):
                        print(f"{key}:")
                        for subkey, subvalue in value.items():
                            print(f"  {subkey}: {subvalue}")
                    else:
                        print(f"{key}: {value}")
            
            # Handle File Signature Analysis
            elif choice == '3':
                print("=== File Signature Analysis ===")
                result = self.file_signature_analysis(file_path)
                # Display signature results
                for key, value in result.items():
                    print(f"{key}: {value}")
            
            # Handle Keyword Search
            elif choice == '4':
                keyword = input("Enter keyword to search: ")
                print("=== Keyword Search ===")
                result = self.keyword_search(self.target_dir, keyword)
                # Display search results
                if isinstance(result, list):
                    for item in result:
                        print(item)
                else:
                    print(result)
            
            # Handle Timeline Analysis
            elif choice == '5':
                print("=== Timeline Analysis ===")
                result = self.timeline_analysis(self.target_dir)
                # Display timeline entries
                if isinstance(result, list):
                    for item in result:
                        print(f"File: {item['File']}")
                        print(f"Created: {item['Created']}")
                        print(f"Modified: {item['Modified']}")
                        print(f"Accessed: {item['Accessed']}\n")
                else:
                    print(result)
            
            # Handle Hidden File Detection
            elif choice == '6':
                print("=== Hidden File Detection ===")
                result = self.detect_hidden_files(self.target_dir)
                # Display hidden files
                if isinstance(result, list):
                    for item in result:
                        print(item)
                else:
                    print(result)
            
            # Handle Log File Parser
            elif choice == '7':
                print("=== Log File Parser ===")
                result = self.parse_log_file(file_path)
                # Display parsed IPs and timestamps
                if isinstance(result, dict):
                    print("IP Addresses:", result["IPs"])
                    print("Timestamps:", result["Timestamps"])
                else:
                    print(result)
            
            # Handle Generate PDF Report
            elif choice == '8':
                print("=== Generate PDF Report ===")
                result = self.generate_pdf_report(output_path)
                print(result)
            
            # Handle Analyze Network Traffic
            elif choice == '9':
                print("=== Analyze Network Traffic (PCAP) ===")
                result = self.analyze_network_traffic(file_path)
                # Display network traffic details
                if isinstance(result, dict):
                    for key, value in result.items():
                        print(f"{key}: {value}")
                else:
                    print(result)
            
            # Handle DeepSeek Chat Assistance
            elif choice == '10':
                print("=== DeepSeek Chat Assistance ===")
                result = self.deepseek_chat_assistance(user_query)
                # Display query and response
                print(f"Query: {result['Query']}")
                print(f"Response: {result['Response']}")
            
            # Handle Open AI Chat Assistance
            elif choice == '11':
                print("=== Open AI Chat Assistance ===")
                result = self.openai_chat_assistance(user_query)
                # Display query and response
                print(f"Query: {result['Query']}")
                print(f"Response: {result['Response']}")
            
            # Handle invalid menu choices
            else:
                print("Invalid choice!")
            
            # Pause for user to review results
            input("\nPress Enter to continue...")

# Entry point of the script
if __name__ == "__main__":
    # Create an instance of AIFORT
    aifort = AIFORT()
    # Start the main menu loop
    aifort.run()